/**
 * This package contains the implementation of the V2I intersection manager.
 */
package aim4.im.v2i;
