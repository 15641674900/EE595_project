/**
 * This package contains the implementations of the map in the AIM4 simulator.
 */
package aim4.map;
