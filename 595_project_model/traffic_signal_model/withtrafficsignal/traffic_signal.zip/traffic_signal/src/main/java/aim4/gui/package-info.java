/**
 * This package contains the implementation of the GUI of the simulator.
 */
package aim4.gui;
