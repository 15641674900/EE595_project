/**
 * This package contains the implementations of the lane objects in the map.
 */
package aim4.map.lane;
