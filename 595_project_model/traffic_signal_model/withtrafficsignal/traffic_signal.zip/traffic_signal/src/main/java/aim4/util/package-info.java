/**
 * This package contains some helper functions and classes.
 */
package aim4.util;
