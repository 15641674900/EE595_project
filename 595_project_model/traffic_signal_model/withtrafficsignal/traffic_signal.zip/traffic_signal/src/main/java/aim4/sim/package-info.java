/**
 * This package contains the implementation of the simulation object of
 * the simulator.
 */
package aim4.sim;
