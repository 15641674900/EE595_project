/**
 * This package contains the implementation of the coordinator,
 * one of the three agents in the driver agent.
 */
package aim4.driver.coordinator;
