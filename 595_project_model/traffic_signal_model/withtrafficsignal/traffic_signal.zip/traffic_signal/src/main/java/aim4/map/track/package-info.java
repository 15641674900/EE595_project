/**
 * This package contains the track objects for the map.
 */
package aim4.map.track;
