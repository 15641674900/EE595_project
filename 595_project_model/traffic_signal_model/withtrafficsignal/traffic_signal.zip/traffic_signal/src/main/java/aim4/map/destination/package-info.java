/**
 * This package contains the implementations of the destination selectors.
 */
package aim4.map.destination;
