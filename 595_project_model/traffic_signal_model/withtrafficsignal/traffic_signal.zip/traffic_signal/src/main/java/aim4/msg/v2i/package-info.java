/**
 * This package contains the implementation of the V2I messages in the
 * AIM protocol.
 */
package aim4.msg.v2i;
