/**
 * This packages contains the driver model.
 */
package aim4.driver;
